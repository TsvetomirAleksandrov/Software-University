﻿namespace BookShop.DataProcessor.ImportDto
{
    public class ImportAuthorBookDto
    {
        public int Id { get; set; }
    }
}