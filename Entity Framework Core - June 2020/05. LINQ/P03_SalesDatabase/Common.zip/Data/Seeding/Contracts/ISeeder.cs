﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data.Seeding.Contracts
{
    public interface ISeeder
    {
        void Seed();
    }
}
