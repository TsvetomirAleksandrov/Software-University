﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.\SQLEXPRESS;Database=Sales;Integrated Security=true;";
    }
}
