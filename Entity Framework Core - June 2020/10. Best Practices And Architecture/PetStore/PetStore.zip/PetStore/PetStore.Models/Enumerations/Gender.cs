﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PetStore.Models.Enumerations
{
    public enum Gender
    {
        Male = 1,
        Female = 2
    }
}
