﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PetStore.Common
{
    public static class DbConfiguraton
    {
        public static string DefConnectionString = "Server=.//SQLEXPRESS;Database=PetStore;Integrated Security=true;";
    }
}
