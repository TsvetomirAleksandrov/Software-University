﻿using System;

namespace PetStore.ConsoleApplication
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
