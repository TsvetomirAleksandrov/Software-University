﻿using System;

namespace ShoppingSpree
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine newEngine = new Engine();
            newEngine.Run();
        }
    }
}
