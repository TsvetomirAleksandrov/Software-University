﻿using System;
using System.Collections.Generic;
using System.Text;

public class GoldItem : Item
{
    public GoldItem(string key, long value)
    {
        Key = key;
        Value = value;
    }
}