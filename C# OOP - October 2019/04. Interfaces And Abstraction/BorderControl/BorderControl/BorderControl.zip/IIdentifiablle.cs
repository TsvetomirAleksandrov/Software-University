﻿namespace BorderControl
{
    public interface IIdentifiablle
    {
        string Id { get; }
    }
}
