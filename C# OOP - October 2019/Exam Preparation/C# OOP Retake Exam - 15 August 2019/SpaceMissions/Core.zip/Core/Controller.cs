﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceStation.Core
{
    using SpaceStation.Core.Contracts;
    using SpaceStation.Models.Astronauts;
    using SpaceStation.Models.Astronauts.Contracts;
    using SpaceStation.Models.Mission;
    using SpaceStation.Models.Planets;
    using SpaceStation.Repositories;
    using SpaceStation.Utilities.Messages;
    using System.Linq;

    public class Controller : IController
    {
        private AstronautRepository astronautRep;
        private PlanetRepository planetRep;
        private Mission mission;
        private int exploredPlanets;
        public Controller()
        {
            this.astronautRep = new AstronautRepository();
            this.planetRep = new PlanetRepository();
            this.mission = new Mission();
            this.exploredPlanets = 0;
        }
        public string AddAstronaut(string type, string astronautName)
        {
            if (type == "Meteorologist")
            {
                astronautRep.Add(new Meteorologist(astronautName));
                return string.Format(OutputMessages.AstronautAdded, type, astronautName);
            }
            else if (type == "Geodesist")
            {
                astronautRep.Add(new Geodesist(astronautName));
                return string.Format(OutputMessages.AstronautAdded, type, astronautName);
            }
            else if (type == "Biologist")
            {
                astronautRep.Add(new Biologist(astronautName));
                return string.Format(OutputMessages.AstronautAdded, type, astronautName);
            }
            else
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.InvalidAstronautType));
            }
        }

        public string AddPlanet(string planetName, params string[] items)
        {
            IPlanet planet = new Planet(planetName);
            for (int i = 0; i < items.Length; i++)
            {
                planet.Items.Add(items[i]);
            }

            planetRep.Add(planet);
            return string.Format(OutputMessages.PlanetAdded, planetName);

        }

        public string ExplorePlanet(string planetName)
        {
            if (!astronautRep.Models.Any(x => x.Oxygen > 60))
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.InvalidAstronautCount));
            }

            List<IAstronaut> astronautsGoodToExplore = astronautRep.Models.Where(x => x.Oxygen > 60).ToList();
            var planet = planetRep.FindByName(planetName);
            mission.Explore(planet, astronautsGoodToExplore);

            var deadAstronauts = astronautsGoodToExplore.Where(x => !x.CanBreath).ToList().Count;
            this.exploredPlanets++;
            return string.Format(OutputMessages.PlanetExplored, planetName, deadAstronauts);
        }

        public string Report()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"{this.exploredPlanets} planets were explored!");
            sb.AppendLine("Astronauts info:");
            foreach (var astronaut in astronautRep.Models)
            {
                sb.AppendLine($"Name: {astronaut.Name}");
                sb.AppendLine($"Oxygen: {astronaut.Oxygen}");
                if (astronaut.Bag.Items.Count == 0)
                {
                    sb.AppendLine($"Bag items: none");
                }
                else
                {
                    sb.AppendLine($"Bag items: {string.Join(", ",astronaut.Bag.Items)}");
                }
            }

            return sb.ToString().TrimEnd();
        }

        public string RetireAstronaut(string astronautName)
        {
            if (astronautRep.FindByName(astronautName) == null)
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.InvalidRetiredAstronaut, astronautName));
            }

            astronautRep.Remove(astronautRep.FindByName(astronautName));
            return string.Format(OutputMessages.AstronautRetired, astronautName);
        }
    }
}
