﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using SpaceStation.Models.Astronauts.Contracts;
using SpaceStation.Models.Planets;

namespace SpaceStation.Models.Mission
{
    public class Mission : IMission
    {
        //public void Explore(IPlanet planet, ICollection<IAstronaut> astronauts)
        //{
        //    foreach (var astronaut in astronauts)
        //    {
        //        while (astronaut.CanBreath && planet.Items.Count > 0)
        //        {
        //            string item = planet.Items.ElementAt(0);
        //            planet.Items.Remove(planet.Items.ElementAt(0));
        //            astronaut.Bag.Items.Add(item);
        //            astronaut.Breath();
        //        }
        //    }
        //}

        public void Explore(IPlanet planet, ICollection<IAstronaut> astronauts)
        {
            var removedItems = new List<string>();
            foreach (var currentAstronaut in astronauts)
            {
                if (!currentAstronaut.CanBreath)
                {
                    continue;
                }
                foreach (var currenItem in planet.Items)
                {
                    currentAstronaut.Bag.Items.Add(currenItem);
                    currentAstronaut.Breath();
                    removedItems.Add(currenItem);
                    planet.Items.Remove(currenItem);

                    if (!currentAstronaut.CanBreath)
                    {
                        break;
                    }
                }

            }
        }
    }
}
