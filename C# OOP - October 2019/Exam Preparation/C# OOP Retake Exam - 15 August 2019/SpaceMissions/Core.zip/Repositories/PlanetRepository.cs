﻿using SpaceStation.Models.Planets;
using SpaceStation.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SpaceStation.Repositories
{
    public class PlanetRepository : IRepository<IPlanet>
    {
        private Dictionary<string, IPlanet> planetsRep;
        public PlanetRepository()
        {
            this.planetsRep = new Dictionary<string, IPlanet>();
        }
        public IReadOnlyCollection<IPlanet> Models => this.planetsRep.Values.ToList().AsReadOnly();

        public void Add(IPlanet model)
        {
            planetsRep.Add(model.Name, model);
        }

        public IPlanet FindByName(string name)
        {
            return planetsRep[name];
        }

        public bool Remove(IPlanet model)
        {
            return planetsRep.Remove(model.Name);
        }
    }
}
